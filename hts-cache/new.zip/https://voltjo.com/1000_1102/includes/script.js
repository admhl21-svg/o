let timerId = null; 
const label = document.getElementById('autoJbLabel');
const checkbox = document.getElementById('autoJbInput');
const jeilbrekBtn = document.getElementById('jeilbrek');
const UAElement = document.getElementById("UA");

const storedAutoJb = localStorage.getItem("autoJb");
let autoJbValue = storedAutoJb !== null ? storedAutoJb === "true" : true;

// اختر أحد عمليات استغلال النواة
var exploitChain = localStorage.getItem("exploitChain") || "lapse";
const netctrlRadio = document.getElementById("netctrl-exploit");
const lapseRadio = document.getElementById("lapse-exploit");
const kexForm = document.getElementById('kernel-options');

// عرض معلومات المتصفح
UAElement.innerText += " " + navigator.userAgent;

kexForm.addEventListener("change", function (event) {
    localStorage.setItem("exploitChain", event.target.value);
    exploitChain = event.target.value;
});

// تنفيذ الجيلبريك
jeilbrekBtn.addEventListener("click", function (e){
    jeilbrekBtn.disabled = true;
    stopInterval();
    doJb();
});

checkbox.addEventListener('change', function () {
    localStorage.setItem("autoJb", checkbox.checked);
    if (checkbox.checked == true && jeilbrekBtn.disabled == false) {
        jailbreakCountdown();
        return;
    }

    stopInterval();
});

function stopInterval(){
    if (timerId !== null) {
        clearInterval(timerId);
        timerId = null;
    }
    label.textContent = "جيلبريك تلقائي";
}

function jailbreakCountdown() {   
    stopInterval();

    let countdown = 5;
    label.textContent = `الجيلبريك التلقائي خلال: ${countdown}`;
    timerId = setInterval(() => {
        countdown--;
        label.textContent = `الجيلبريك التلقائي خلال: ${countdown}`;

        if (countdown < 0) {
            jeilbrekBtn.disabled = true; 
            clearInterval(timerId);
            timerId = null;
            label.textContent = 'جارٍ التنفيذ';
            doJb();
        }
    }, 1000);
}

function cacheProgress(e) {
    var Percent = (Math.round(e.loaded / e.total * 100));
    document.title = "جارٍ التخزين: " + Percent + "%";
}

function displayCacheProgress() {
    setTimeout(function () {
        // إظهار علامة صح
        document.title = "\u2713";
    }, 1000);
    setTimeout(function () {
        // location.reload();
        document.title = "CSSFontFace exploit";
    }, 3000);
}

function initScript() {
    if (window.applicationCache) {
        window.applicationCache.addEventListener("progress", cacheProgress, false);
        window.applicationCache.oncached = function (e) { displayCacheProgress(); };
        window.applicationCache.onupdateready = function (e) { displayCacheProgress(); };
    }

    if (exploitChain == "netctrl") {
        if (netctrlRadio) netctrlRadio.checked = true;
    } else {
        if (lapseRadio) lapseRadio.checked = true;
    }

    if (checkbox) checkbox.checked = autoJbValue;

    if (autoJbValue) jailbreakCountdown();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initScript);
} else {
    initScript();
}
